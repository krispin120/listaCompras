package com.sebastian.listacompras;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ListacomprasApplicationTests {

	@Test
	void contextLoads() {
	}

}
